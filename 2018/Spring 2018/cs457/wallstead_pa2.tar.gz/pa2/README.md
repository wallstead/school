# SQ🔥 (SQLit) 

This is a bare-bones database management system for my cs457 class at UNR.

Don't use this for anything of importance, or really anything for that matter. (It wasn't designed to be efficient)
