Author: Josh Pike
Compiles using 'make' command
Compiles on Virtual Box Ubuntu VM