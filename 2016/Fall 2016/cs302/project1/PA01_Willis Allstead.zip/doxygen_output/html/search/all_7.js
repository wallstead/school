var searchData=
[
  ['setitem',['setItem',['../class_node.html#ab4ceecdecc5df799011de486b9f54974',1,'Node']]],
  ['setnext',['setNext',['../class_node.html#a01c1a66d4e39f5b149e090413deb4633',1,'Node']]]
];
