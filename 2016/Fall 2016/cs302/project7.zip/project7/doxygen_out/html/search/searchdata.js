var indexSectionsWithContent =
{
  0: "bgiprs",
  1: "br",
  2: "bpr",
  3: "gis"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

